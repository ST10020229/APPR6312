using Microsoft.AspNetCore.Mvc;
using DisasterReliefApp.Models;
using System.Threading.Tasks;
using DisasterReliefApp.Models.DisasterReliefApp.Models;

namespace DisasterReliefApp.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(User user)
        {
            if (ModelState.IsValid)
            {
                _context.User.Add(user);
                await _context.SaveChangesAsync();
                return RedirectToAction("Login");
            }
            return View(user);
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }  

        // Implement login logic here
    }
}
