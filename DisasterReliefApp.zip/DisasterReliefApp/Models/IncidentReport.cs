namespace DisasterReliefApp.Models
{
    using System;
    using System.ComponentModel.DataAnnotations;

    using System;
    using System.ComponentModel.DataAnnotations;

    namespace DisasterReliefApp.Models
    {
        public class IncidentReport
        {
            [Key]
            public int Id { get; set; }
            public string Title { get; set; }
            public string Description { get; set; }
            public DateTime DateReported { get; set; }
            public string Location { get; set; }
            public int UserId { get; set; } // Foreign key to User
            public User User { get; set; } // Navigation property
        }
    }


}
