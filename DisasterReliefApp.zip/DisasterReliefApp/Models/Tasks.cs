namespace DisasterReliefApp.Models
{
    using System;
    using System.ComponentModel.DataAnnotations;

    namespace DisasterReliefApp.Models
    {
        public class Tasks
        {
            public int Id { get; set; }

            [Required]
            public string Title { get; set; }

            [Required]
            public string Description { get; set; }

            public DateTime DueDate { get; set; }

            public int VolunteerId { get; set; } // Foreign key to Volunteer
            public Volunteer Volunteer { get; set; } // Navigation property
        }
    }

}

