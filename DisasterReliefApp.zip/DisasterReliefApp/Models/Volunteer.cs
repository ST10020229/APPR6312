namespace DisasterReliefApp.Models
{
    using System.ComponentModel.DataAnnotations;

    using System.ComponentModel.DataAnnotations;

    namespace DisasterReliefApp.Models
    {
        public class Volunteer
        {
            [Key]
            public int Id { get; set; }
            public string TaskName { get; set; }
            public string Description { get; set; }
            public DateTime DueDate { get; set; }
            public bool IsCompleted { get; set; }
        }
    }


}

