﻿using Azure.Storage.Blobs;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Threading.Tasks;

public class StorageService
{
    private readonly BlobServiceClient _blobServiceClient;

    public StorageService(IConfiguration configuration)
    {
        // Retrieve the connection string from the configuration
        string connectionString = configuration.GetConnectionString("AzureStorageConnection");

        // Create a BlobServiceClient using the connection string
        _blobServiceClient = new BlobServiceClient(connectionString);
    }

    public async Task UploadBlobAsync(string containerName, string blobName, Stream data)
    {
        // Get a reference to a container
        var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);

        // Create the container if it doesn't already exist
        await containerClient.CreateIfNotExistsAsync();

        // Get a reference to the blob
        var blobClient = containerClient.GetBlobClient(blobName);

        // Upload the blob
        await blobClient.UploadAsync(data, true);
    }
}
