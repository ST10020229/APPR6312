using DisasterReliefApp.Models.DisasterReliefApp.Models;
using Microsoft.EntityFrameworkCore;

namespace DisasterReliefApp.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<IncidentReport> IncidentReports { get; set; }
        public DbSet<Donation> Donations { get; set; }
        public DbSet<Volunteer> VolunteerTasks { get; set; }
    }
}
